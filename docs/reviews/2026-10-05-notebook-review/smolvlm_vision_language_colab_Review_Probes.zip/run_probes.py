"""SVL review probes (torch-free). Usage: python run_probes.py <repo checkout> <out dir>"""
import io, json, sys, types, zipfile, re
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/smolvlm_vision_language_colab.ipynb'
nb = json.loads(NB.read_text())
cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
import smolvlm_vision_language_pipeline.samples as S  # torch-free
assert 'torch' not in sys.modules
R = {}

# P1 static: install pattern, asserts, guided layer, cell inventory
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
alltext = '\n'.join(src(i) for i in range(len(cells)))
R['P1_static'] = {
    'cells': len(cells), 'code_cells': len(code),
    'install_cell_pip_in_kernel': "'-m', 'pip', 'install'" in src(3),
    'restart_guard_text': 'Restart the runtime, then rerun from the top.' in src(3),
    'declared': nb['metadata']['dimer'].get('notebook_profile'), 'mode': nb['metadata']['dimer'].get('notebook_mode'), 'spec': nb['metadata']['dimer'].get('notebook_spec'),
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')),
    'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'asserts_on_quality': [(i, l.strip()) for i in code for l in src(i).splitlines() if l.strip().startswith('assert ')],
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Predict', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Conclusion', '<details>']},
    'persisted_outputs': sum(len(c.get('outputs', [])) for c in cells if c['cell_type'] == 'code'),
}
pipe_src = (repo / 'src/smolvlm_vision_language_pipeline/pipeline.py').read_text()
R['P1_static']['adapt_initial_state_from_live_model'] = 'frozen_state = {k: v.detach().clone() for k, v in model.state_dict().items() if k in name_set}' in pipe_src
R['P1_static']['epoch0_note'] = '"note": "frozen model"' in pipe_src

def line(i, w=200):
    im = Image.new('RGB', (w, 32), 'white'); d = ImageDraw.Draw(im); d.text((4, 8), f'line {i}', fill='black')
    d.point([(i % w, 0)], fill=(i % 256, (i * 7) % 256, 3))
    return im

def png(im):
    b = io.BytesIO(); im.save(b, 'PNG'); return b.getvalue()

def mkzip(path, files):
    with zipfile.ZipFile(path, 'w') as z:
        for n, d in files.items():
            z.writestr(n, d)
    return path

def nb_byod_path(zpath, seed=42):
    """The BYOD branch of cell 13 after the upload: load -> split -> validate_dataset per split -> disjoint."""
    records = S.load_byod_dataset(zpath)
    splits = S.split_dataset(records, seed=seed)
    man = {k: S.validate_dataset(v) for k, v in splits.items()}
    S.check_split_disjoint({k: m['records'] for k, m in man.items()})
    return {k: m['n_records'] for k, m in man.items()}

def run(name, fn):
    try:
        return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e:  # noqa
        return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:200]}

def dataset(n, prefix=''):
    files = {f'{prefix}img{i}.png': png(line(i)) for i in range(n)}
    csv = 'file,text\n' + ''.join(f'img{i}.png,ligne numero {i}\n' for i in range(n))
    files[f'{prefix}transcripts.csv'] = csv.encode()
    return files

zd = out / 'zips'; zd.mkdir(exist_ok=True)
# P2 effective BYOD minimum (stated: at least eight images)
mins = {}
for n in [8, 12, 20, 30, 37, 38, 40, 49, 50, 60]:
    mins[n] = run(f'{n} images', lambda n=n: nb_byod_path(mkzip(zd / f'n{n}.zip', dataset(n))))
first_ok = next((n for n in sorted(mins) if mins[n]['verdict'] == 'accepted'), None)
exhaustive = None
for n in range(8, 80):
    r = run('n', lambda n=n: nb_byod_path(mkzip(zd / 'scan.zip', dataset(n))))
    if r['verdict'] == 'accepted':
        exhaustive = n; break
R['P2_byod_minimum'] = {'stated_minimum': 8, 'smallest_accepted': exhaustive, 'samples': mins}

# P3 BYOD matrix
cases = {}
base = dataset(60)
cases['good: 60 images'] = base
cases['good: nested folder'] = {('data/' + k): v for k, v in base.items()}
mac = dict(base); mac['__MACOSX/._img0.png'] = b'\x00\x05\x16\x07junk'
cases['macOS zip with __MACOSX/._img0.png'] = mac
readme = dict(base); readme['README.txt'] = b'my lines'
cases['zip with README.txt'] = readme
dup = dict(base); dup['b/img0.png'] = png(Image.new('RGB', (300, 40), 'black'))
cases['two folders both holding img0.png (basename collision)'] = dup
miss = dict(base); miss['transcripts.csv'] = base['transcripts.csv'] + b'img999.png,absent\n'
cases['transcripts.csv names a missing image'] = miss
nocsv = {k: v for k, v in base.items() if k != 'transcripts.csv'}
cases['no transcripts.csv'] = nocsv
badcol = dict(base); badcol['transcripts.csv'] = b'filename,transcript\nimg0.png,x\n'
cases['wrong column names'] = badcol
empty = dict(base); empty['transcripts.csv'] = base['transcripts.csv'].replace(b'ligne numero 3\n', b'\n')
cases['one empty transcript'] = empty
txtimg = dict(base); txtimg['img1.png'] = b'not an image'
cases['undecodable image'] = txtimg
huge = dict(base); huge['img2.png'] = png(Image.new('RGB', (16385, 20), 'white'))
cases['image wider than 16,384 px'] = huge
same = dataset(60); 
for i in range(1, 60): same[f'img{i}.png'] = same['img0.png']
cases['60 identical images (all de-duplicated)'] = same
P3 = []
for name, files in cases.items():
    r = run(name, lambda files=files, name=name: nb_byod_path(mkzip(zd / (re.sub('[^a-z0-9]+', '_', name.lower())[:40] + '.zip'), files)))
    P3.append(r)
# what the collision does to the record set
recs = S.load_byod_dataset(zd / (re.sub('[^a-z0-9]+', '_', 'two folders both holding img0.png (basename collision)'.lower())[:40] + '.zip'))
r0 = [r for r in recs if r['id'] == 'img0'][0]
R['P3_byod_matrix'] = P3
R['P3_collision_detail'] = {'records': len(recs), 'img0_size_used': list(r0['image'].size), 'img0_text': r0['text'], 'note': 'root img0.png (200x32) silently replaced by b/img0.png (300x40, black); the img0 transcript is now attached to the black image'}

# P4 upload branch of cell 13 executed with stand-ins
c13 = src(13).replace('USE_BYOD = False', 'USE_BYOD = True')
head = c13.split('    records = load_byod_dataset')[0]
def exec_upload(uploaded):
    colab = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = colab
    colab.files = types.SimpleNamespace(upload=lambda: uploaded)
    sys.modules['google'] = g; sys.modules['google.colab'] = colab
    ns = {'Path': Path, 'os': __import__('os')}
    import os; cwd = os.getcwd(); os.chdir(out)
    try:
        exec(compile(head, 'cell13', 'exec'), ns); return {'file_name': ns.get('file_name')}
    finally:
        os.chdir(cwd)
P4 = {}
for name, up in {'cancelled dialog (empty dict)': {}, 'two files selected': {'a.zip': b'PK', 'b.zip': b'PK'}}.items():
    P4[name] = run(name, lambda up=up: exec_upload(up))
for k in ('google', 'google.colab'):
    sys.modules.pop(k, None)
def outside_colab():
    exec(compile(head, 'cell13', 'exec'), {'Path': Path, 'os': __import__('os')})
P4['outside Colab (no google.colab)'] = run('outside', outside_colab)
P4['has_path_field'] = bool(re.search(r'BYOD_(PATH|ZIP|DIR)\s*=', src(13)))
R['P4_upload_branch'] = P4

(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:6000])

# P5 prose against code/record (SVL)
md = {i: src(i) for i, c in enumerate(cells) if c['cell_type'] == 'markdown'}
import importlib
P = importlib.import_module('smolvlm_vision_language_pipeline.pipeline')
R['P5_prose'] = {
    'cell18_says_four_trainable_layers': 'only the four trainable layers' in md[18],
    'cell18_says_last_eight': 'last eight of the 32' in md[18],
    'TRAINABLE_LAYERS': P.TRAINABLE_LAYERS, 'DECODER_LAYERS': P.DECODER_LAYERS,
    'cell18_reads_1_minus_cer_as_chars_right': '11 % of the characters right' in md[18],
    'drawing_size_in_code': re.search(r"Image.new\('RGB', \((\d+), (\d+)\)", src(15)).groups(),
    'registry_row_says_512x512': '512×512 drawing' in (repo / 'tutorials/README.md').read_text(),
    'MIN_IMAGE_SIDE': P.MIN_IMAGE_SIDE,
    'optional_experiment_rerun_section6': 'rerun from Section 6' in md[24],
}
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R['P5_prose'], indent=1))
